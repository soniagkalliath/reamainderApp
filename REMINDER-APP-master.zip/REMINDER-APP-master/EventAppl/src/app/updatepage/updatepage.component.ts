import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, Validators, ɵInternalFormsSharedModule } from '@angular/forms';



@Component({
  selector: 'app-updatepage',
  templateUrl: './updatepage.component.html',
  styleUrls: ['./updatepage.component.css']
})

export class UpdatepageComponent implements OnInit {








  constructor() {


  }




  ngOnInit(): void {
  }

}